<?php
	function duplicator_header($title)
	{
		echo "<h1>{$title}</h1>";
	}
?>